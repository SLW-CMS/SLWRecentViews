// Kaynak kodu görüntüleyenlere özel mesaj
if (window.location.href.startsWith("view-source")) {
    console.log("Kral kaynağa bakıp ne göreceksin orada? bana sorsana merak ettiğin şeyi..");
} else {
    console.log("Kardeşim gez dolaş sitedeki içerikler ücretsiz korkma :)");
}
