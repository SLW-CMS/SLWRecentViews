=== SLW Recent Views ===
Contributors: your-username
Donate link: https://rootali.net/
Tags: views, logs, visitors, tracking, wordpress
Requires at least: 5.0
Tested up to: 6.3
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
SLW Recent Views eklentisi, ziyaretçilerin sayfada yaptığı işlemleri kaydeder ve log dosyasına yazar. IP adresi, şehir bilgisi, ve ziyaret edilen sayfa bilgilerini içerir.

== Installation ==
1. Eklenti dosyasını indirin ve `/wp-content/plugins/` dizinine yükleyin.
2. WordPress yönetim panelinde "Eklentiler" menüsünden etkinleştirin.

== Changelog ==
= 1.0 =
* İlk sürüm.
